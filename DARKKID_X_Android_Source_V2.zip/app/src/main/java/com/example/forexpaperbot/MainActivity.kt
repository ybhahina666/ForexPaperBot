package com.example.forexpaperbot

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val bg = Color.rgb(7, 8, 12)
    private val panel = Color.rgb(20, 21, 29)
    private val red = Color.rgb(255, 35, 68)
    private val green = Color.rgb(58, 220, 155)
    private val muted = Color.rgb(165, 169, 182)
    private var symbol = "EUR/USD"
    private var price = 0.0
    private var closes: List<Double> = emptyList()
    private var signal = "WAIT"
    private var balance = 10000.0
    private var openTrade: PaperTrade? = null
    private var lastUpdated = "Not connected"
    private var isLoading = false
    private lateinit var apiKeyInput: EditText
    private lateinit var priceView: TextView
    private lateinit var signalView: TextView
    private lateinit var statusView: TextView
    private lateinit var balanceView: TextView
    private lateinit var tradeView: TextView
    private lateinit var logView: TextView
    private lateinit var symbolSpinner: Spinner

    data class PaperTrade(val side: String, val entry: Double, val symbol: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        refreshUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(28))
            setBackgroundColor(bg)
        }
        page.addView(label("DARKKID X", 30f, Color.WHITE, true))
        page.addView(label("TRADING ASSISTANT  •  V2", 13f, red, true))
        page.addView(label("LIVE DATA · PAPER TRADING ONLY", 12f, muted, true))
        page.addView(space(14))

        val marketCard = card()
        marketCard.addView(label("MARKET", 12f, muted, true))
        symbolSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("EUR/USD", "GBP/USD", "USD/JPY", "AUD/USD", "USD/CAD", "XAU/USD"))
            setSelection(0)
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                    val next = parent?.getItemAtPosition(position)?.toString() ?: return
                    if (next != symbol) { symbol = next; price = 0.0; closes = emptyList(); signal = "WAIT"; refreshUi() }
                }
            }
        }
        marketCard.addView(symbolSpinner)
        priceView = label("—", 36f, Color.WHITE, true)
        marketCard.addView(priceView)
        statusView = label("Not connected · Add your market-data API key", 12f, muted)
        marketCard.addView(statusView)
        page.addView(marketCard)
        page.addView(space(12))

        val keyCard = card()
        keyCard.addView(label("MARKET DATA CONNECTION", 13f, Color.WHITE, true))
        keyCard.addView(label("Twelve Data API key (required for live forex quotes)", 12f, muted))
        apiKeyInput = EditText(this).apply {
            hint = "Paste API key here"
            setHintTextColor(muted)
            setTextColor(Color.WHITE)
            textSize = 14f
            singleLine = true
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setBackgroundColor(Color.rgb(34, 35, 44))
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        keyCard.addView(apiKeyInput, LinearLayout.LayoutParams(-1, dp(48)))
        val connect = Button(this).apply {
            text = "CONNECT & GET LIVE DATA"
            setTextColor(Color.WHITE); setBackgroundColor(red)
            setOnClickListener { fetchMarketData() }
        }
        keyCard.addView(connect, LinearLayout.LayoutParams(-1, dp(48)))
        page.addView(keyCard)
        page.addView(space(12))

        val signalCard = card()
        signalCard.addView(label("AI-STYLE INDICATOR", 13f, muted, true))
        signalView = label("WAIT", 30f, Color.YELLOW, true)
        signalCard.addView(signalView)
        signalCard.addView(label("Rule: 5-period EMA vs 12-period EMA on recent 1-minute candles. Educational indicator, not a guarantee.", 12f, muted))
        page.addView(signalCard)
        page.addView(space(12))

        val accountCard = card()
        accountCard.addView(label("PAPER ACCOUNT", 13f, muted, true))
        balanceView = label("Virtual balance: $10,000.00", 20f, Color.WHITE, true)
        accountCard.addView(balanceView)
        tradeView = label("No open simulated trade", 13f, muted)
        accountCard.addView(tradeView)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        actions.addView(actionButton("PAPER BUY", green) { openPaperTrade("BUY") }, LinearLayout.LayoutParams(0, dp(48), 1f))
        actions.addView(actionButton("PAPER SELL", red) { openPaperTrade("SELL") }, LinearLayout.LayoutParams(0, dp(48), 1f))
        actions.addView(actionButton("CLOSE", Color.rgb(75, 78, 91)) { closePaperTrade() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        accountCard.addView(actions)
        page.addView(accountCard)
        page.addView(space(12))

        val logCard = card()
        logCard.addView(label("ACTIVITY LOG", 13f, Color.WHITE, true))
        logView = label("App ready. No real orders are sent.\n", 12f, muted)
        logCard.addView(logView)
        page.addView(logCard)
        page.addView(space(10))
        page.addView(label("Data note: Live quotes require your own Twelve Data API key and internet access. API limits may apply. Never enter broker passwords. This app only simulates trades and cannot place real orders.", 12f, Color.rgb(255, 183, 117)))
        scroll.addView(page)
        setContentView(scroll)
    }

    private fun fetchMarketData() {
        val key = apiKeyInput.text.toString().trim()
        if (key.isBlank()) { statusView.text = "API key needed · No live data yet"; addLog("Paste a Twelve Data API key first."); return }
        if (isLoading) return
        isLoading = true
        statusView.text = "Connecting to Twelve Data…"
        io.execute {
            var connection: HttpURLConnection? = null
            try {
                val encodedSymbol = URLEncoder.encode(symbol, "UTF-8")
                val encodedKey = URLEncoder.encode(key, "UTF-8")
                val url = URL("https://api.twelvedata.com/time_series?symbol=$encodedSymbol&interval=1min&outputsize=30&apikey=$encodedKey")
                connection = (url.openConnection() as HttpURLConnection).apply { requestMethod = "GET"; connectTimeout = 12000; readTimeout = 12000 }
                val text = connection.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(text)
                if (json.has("status") && json.optString("status") == "error") throw Exception(json.optString("message", "API error"))
                val values = json.optJSONArray("values") ?: throw Exception(json.optString("message", "No candle data returned"))
                val parsed = mutableListOf<Double>()
                for (i in values.length() - 1 downTo 0) {
                    val v = values.getJSONObject(i).optString("close").toDoubleOrNull()
                    if (v != null && v > 0) parsed.add(v)
                }
                if (parsed.size < 13) throw Exception("Not enough candles to calculate signal")
                runOnUiThread {
                    closes = parsed
                    price = parsed.last()
                    signal = calculateSignal(parsed)
                    lastUpdated = java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(java.util.Date())
                    statusView.text = "Connected · Updated $lastUpdated · 1-minute candles"
                    addLog("Updated $symbol live quote: ${fmt(price)} · Signal $signal")
                    refreshUi()
                    handler.removeCallbacks(autoRefresh)
                    handler.postDelayed(autoRefresh, 60000)
                    isLoading = false
                }
            } catch (e: Exception) {
                runOnUiThread {
                    statusView.text = "Connection failed · Check key, internet or API limit"
                    addLog("Data error: ${e.message ?: "Unknown error"}")
                    isLoading = false
                    refreshUi()
                }
            } finally { connection?.disconnect() }
        }
    }

    private val autoRefresh = object : Runnable {
        override fun run() { fetchMarketData() }
    }

    private fun calculateSignal(values: List<Double>): String {
        fun ema(period: Int): Double {
            val alpha = 2.0 / (period + 1.0)
            var result = values.take(period).average()
            for (v in values.drop(period)) result = alpha * v + (1 - alpha) * result
            return result
        }
        val fast = ema(5)
        val slow = ema(12)
        val difference = fast - slow
        val threshold = values.last() * 0.00003
        return when { difference > threshold -> "BUY"; difference < -threshold -> "SELL"; else -> "WAIT" }
    }

    private fun openPaperTrade(side: String) {
        if (price <= 0.0) { addLog("Connect to live data before opening a paper trade."); return }
        if (openTrade != null) { addLog("Close the current paper trade first."); return }
        openTrade = PaperTrade(side, price, symbol)
        addLog("Opened PAPER $side $symbol at ${fmt(price)}")
        refreshUi()
    }

    private fun closePaperTrade() {
        val t = openTrade
        if (t == null) { addLog("No open paper trade to close."); return }
        if (price <= 0.0 || t.symbol != symbol) { addLog("Select ${t.symbol} and refresh data before closing this trade."); return }
        val movement = if (t.side == "BUY") price - t.entry else t.entry - price
        val pnl = movement * 1000.0
        balance += pnl
        openTrade = null
        addLog("Closed ${t.side} ${t.symbol} at ${fmt(price)} · simulated P/L ${if (pnl >= 0) "+" else ""}${String.format(Locale.US, "%.2f", pnl)}")
        refreshUi()
    }

    private fun refreshUi() {
        if (!::priceView.isInitialized) return
        priceView.text = if (price > 0) fmt(price) else "—"
        signalView.text = signal
        signalView.setTextColor(when (signal) { "BUY" -> green; "SELL" -> red; else -> Color.YELLOW })
        balanceView.text = "Virtual balance: $" + String.format(Locale.US, "%.2f", balance)
        val t = openTrade
        tradeView.text = if (t == null) "No open simulated trade" else {
            val pnl = if (price > 0 && symbol == t.symbol) (if (t.side == "BUY") price - t.entry else t.entry - price) * 1000.0 else 0.0
            "Open PAPER ${t.side} ${t.symbol} · entry ${fmt(t.entry)} · unrealized P/L ${if (pnl >= 0) "+" else ""}${String.format(Locale.US, "%.2f", pnl)}"
        }
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        setBackgroundColor(panel)
    }
    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color)
        if (bold) setTypeface(null, Typeface.BOLD)
        setPadding(0, dp(5), 0, dp(5))
    }
    private fun actionButton(text: String, color: Int, click: () -> Unit) = Button(this).apply {
        this.text = text; textSize = 11f; setTextColor(Color.WHITE); setBackgroundColor(color); setOnClickListener { click() }
    }
    private fun space(height: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun fmt(v: Double) = String.format(Locale.US, if (symbol == "USD/JPY") "%.3f" else "%.5f", v)
    private fun addLog(message: String) {
        if (!::logView.isInitialized) return
        logView.text = "• $message\n" + logView.text
        if (logView.text.length > 3500) logView.text = logView.text.take(3500)
    }

    override fun onDestroy() {
        handler.removeCallbacks(autoRefresh)
        io.shutdownNow()
        super.onDestroy()
    }
}
