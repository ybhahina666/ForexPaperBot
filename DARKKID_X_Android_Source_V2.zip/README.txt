DARKKID X TRADING ASSISTANT — ANDROID SOURCE V2

WHAT THIS BUILD DOES
- Black/red Android UI branded DARKKID X.
- Fetches recent 1-minute candle data from Twelve Data when you enter your own API key.
- Supports EUR/USD, GBP/USD, USD/JPY, AUD/USD, USD/CAD and XAU/USD (availability depends on your API plan).
- Calculates an illustrative EMA(5) vs EMA(12) BUY / SELL / WAIT indicator from returned candle closes.
- Allows manual simulated paper BUY/SELL and closing, with a virtual balance and activity log.
- Refreshes data about every 60 seconds after a successful connection.
- Never sends broker orders. No broker login is used.

IMPORTANT DATA LIMITATION
This is real provider-supplied market data when connected successfully, but not guaranteed tick-by-tick execution data. Twelve Data API key and internet access are required. Free-plan quotas, supported symbols and delays depend on Twelve Data's current plan. If the API returns an error, the app shows a connection error instead of inventing prices or signals. The EMA indicator is educational and does not guarantee profitable trades.

PRIVACY
The API key is entered into the app and used for requests; this source does not save it to disk. Do not enter broker passwords or account credentials.

BUILD APK
This ZIP is Android Studio source code, not an APK.
1. Extract the ZIP.
2. Open the extracted DARKKID_X_Android_Source folder in Android Studio.
3. Let Gradle sync and install any required SDK components.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK is usually at app/build/outputs/apk/debug/app-debug.apk.

If using Android only, a full Android build environment may not be available on the phone. Do not install APKs from untrusted sources.
